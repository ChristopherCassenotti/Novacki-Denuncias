const { safeExceptionLog } = require("../../utils/safeLog");
const { replaceUserUnitsSchema, userIdParamSchema, createUserSchema, updateUserSchema, replaceUserRolesSchema, changeUserStatusSchema, resetUserPasswordSchema, listUsersQuerySchema, } = require("./users.schema");
const { getUserById, listAssignableRoles, listUsers, createUser: createUserService, updateUser: updateUserService, replaceUserRoles, changeUserStatus, resetUserPassword, replaceUserUnits,} = require("./users.service");

function formatValidationErrors(error){
    return error.issues.map((issue) => ({
        field: issue.path.join('.'),
        message: issue.message,
    }));
}

function sendControllerError(res, error, fallbackMessage){
    if(error.statusCode){
        return res.status(error.statusCode).json({
            message: error.message,
        });
    }

    if(error.code === 'P2002'){
        return res.status(409).json({
            message: 'Já existe um registro com esses dados.',
        });
    }

    safeExceptionLog("admin_user", error);

    return res.status(500).json({
        message: fallbackMessage,
    });
}

async function getUsers(req, res) {
    const validation = listUsersQuerySchema.safeParse(req.query);

    if(!validation.success){
        return res.status(400).json({
            message: 'Filtros de usuários inválidos.',

            errors: formatValidationErrors(validation.error),
        });
    }

    try{
        const result =
  await listUsers(
    validation.data,
    req.auth.userId
  );

        return res.status(200).json({
            data:result,
        });
    }
    catch(error){
        return sendControllerError(res, error, 'Não foi possível listar os usuários.');
    }
}

async function getUser(req, res) {
    const validation = userIdParamSchema.safeParse(req.params);

    if(!validation.success){
        return res.status(400).json({
            message: 'ID de usuário inválido.',

            errors: formatValidationErrors(validation.error),
        });
    }

    try{
        const user =
  await getUserById(
    validation.data.id,
    req.auth.userId
  );

        return res.status(200).json({
            data:{
                user,
            },
        });
    }
    catch(error){
        return sendControllerError(res, error, 'Não foi possível consultar o usuário.');
    }
}

async function getAssignableRoles(
  req,
  res
) {
  try {
    const roles =
      await listAssignableRoles(
        req.auth.userId
      );

    return res
      .status(200)
      .json({
        data: {
          roles,
        },
      });
  } catch (error) {
    return sendControllerError(
      res,
      error,
      "Não foi possível listar os perfis permitidos."
    );
  }
}

async function createUserHandler(req, res) {
    const validation = createUserSchema.safeParse(req.body);

    if(!validation.success){
        return res.status(400).json({
            message: 'Dados do usuário inválidos.',

            errors: formatValidationErrors(validation.error),
        });
    }

    try{
        const result = await createUserService(validation.data, req.auth.userId);

        return res.status(201).json({
            message: 'Usuário criado com sucesso.',
            data: result,
            warning: 'O token de ativação é de uso único e deve ser entregue ao usuário por um canal seguro.',
        });
    }
    catch(error){
        return sendControllerError(res, error, 'Não foi possível criar o usuário.');
    }
}

async function updateUserHandler(req, res) {
  const paramsValidation =
    userIdParamSchema.safeParse(
      req.params
    );

  if (!paramsValidation.success) {
    return res.status(400).json({
      message:
        "ID de usuário inválido.",

      errors:
        formatValidationErrors(
          paramsValidation.error
        ),
    });
  }

  const bodyValidation =
    updateUserSchema.safeParse(
      req.body
    );

  if (!bodyValidation.success) {
    return res.status(400).json({
      message:
        "Dados de atualização inválidos.",

      errors:
        formatValidationErrors(
          bodyValidation.error
        ),
    });
  }

  try {
    const user =
      await updateUserService(
        paramsValidation.data.id,
        bodyValidation.data,
        req.auth.userId
      );

    return res.status(200).json({
      message:
        "Usuário atualizado com sucesso.",

      data: {
        user,
      },
    });
  } catch (error) {
    return sendControllerError(
      res,
      error,
      "Não foi possível atualizar o usuário."
    );
  }
}

async function replaceRolesHandler(req, res) {
    const paramsValidation = userIdParamSchema.safeParse(req.params);

    if(!paramsValidation.success){
        return res.status(400).json({
            message:'ID de usuário inválido.',
        });
    }

    const bodyValidation = replaceUserRolesSchema.safeParse(req.body);

    if(!bodyValidation.success){
        return res.status(400).json({
            message: 'Lista de perfis inválida',
        
            errors: formatValidationErrors(bodyValidation.error)
        });
    }

    try{
        const user = await replaceUserRoles(paramsValidation.data.id, bodyValidation.data.roleIds, req.auth.userId);

        return res.status(200).json({
            message: 'Perfis do usuário atualizados com sucesso.',

            data:{
                user,
            }
        });
    }
    catch(error){
        return sendControllerError(res, error, 'Não foi possível atualizar os perfis do usuário.');
    }
}

async function changeStatusHandler(req, res) {
    const paramsValidation = userIdParamSchema.safeParse(req.params);

    if(!paramsValidation.success){
        return res.status(400).json({
            message: 'ID de usuário inválido',

            errors: formatValidationErrors(paramsValidation.error)
        });
    }

    const bodyValidation = changeUserStatusSchema.safeParse(req.body);

    if(!bodyValidation.success){
        return res.status(400).json({
            message: 'Status de usuário inválido.',

            errors: formatValidationErrors(bodyValidation.error)
        });
    }

    try{
        const user = await changeUserStatus(paramsValidation.data.id, bodyValidation.data.isActive, req.auth.userId);

        return res.status(200).json({
            message: bodyValidation.data.isActive
                ? 'Usuário ativado com sucesso'
                : 'Usuário desativado com sucesso',

            data:{
                user
            }
        });
    }
    catch(error){
        return sendControllerError(res, error, 'Não foi possível alterar o status do usuário.'); 
    }
}

async function resetPasswordHandler(req, res) {
    const paramsValidation = userIdParamSchema.safeParse(req.params);

    if(!paramsValidation.success){
        return res.status(400).json({
            message: 'ID de usuário inválido.',
            
            errors: formatValidationErrors(paramsValidation.error),
        });
    }

    const bodyValidation = resetUserPasswordSchema.safeParse(req.body || {});

    if(!bodyValidation.success){
        return res.status(400).json({
            message: 'Dados de redefinição de senha inválidos.',

            errors: formatValidationErrors(bodyValidation.error),
        });
    }

    try{
        const result = await resetUserPassword(paramsValidation.data.id, req.auth.userId);

        return res.status(200).json({
            message: 'Senha redefinida com sucesso.',

            data: result,

            warning: 'O token de redefinição é de uso único e deve ser entregue ao usuário por um canal seguro.'
        });
    }
    catch(error){
        return sendControllerError(res, error, 'Não foi possível redefinir a senha');
    }
}

async function replaceUnitsHandler(req, res) {
  const paramsValidation =
    userIdParamSchema.safeParse(req.params);

  if (!paramsValidation.success) {
    return res.status(400).json({
      message: "ID de usuário inválido.",
      errors: formatValidationErrors(
        paramsValidation.error
      ),
    });
  }

  const bodyValidation =
    replaceUserUnitsSchema.safeParse(req.body);

  if (!bodyValidation.success) {
    return res.status(400).json({
      message: "Lista de unidades inválida.",
      errors: formatValidationErrors(
        bodyValidation.error
      ),
    });
  }

  try {
    const user = await replaceUserUnits(
      paramsValidation.data.id,
      bodyValidation.data.unitIds,
      req.auth.userId
    );

    return res.status(200).json({
      message:
        "Unidades do usuário atualizadas com sucesso.",
      data: {
        user,
      },
    });
  } catch (error) {
    return sendControllerError(
      res,
      error,
      "Não foi possível atualizar as unidades do usuário."
    );
  }
}
module.exports = { getUser, getUsers, getAssignableRoles,  createUserHandler, updateUserHandler, replaceRolesHandler, changeStatusHandler, resetPasswordHandler, replaceUnitsHandler };
